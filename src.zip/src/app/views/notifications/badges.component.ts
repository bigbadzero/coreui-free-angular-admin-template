import { Component } from '@angular/core';

@Component({
  templateUrl: 'badges.component.html'
})
export class BadgesComponent {

  constructor() { }

}
